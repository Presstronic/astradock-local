# AstraDock — design decisions

Authoritative. Where this file and any \`.dc.html\` specimen disagree, this
file wins. Code contract lives in \`tokens/astradock.css\`.

Requirements source: repo issues. Primary #7, #18, #33, #36–#42.
Supporting #12, #22, #24, #25, #27, #29, #30, #31, #32.

---

## 1. Naming

The product surface is **Runtime Monitor**, not "Log Monitor" (#18, #33, #41, #42).

## 2. Palette — LOCKED

AstraDock keeps its own values: accent **#38B6FF** on canvas **#07090D**.
This is a deliberate, recorded deviation from the bound Station Design System
(cornflower **#53AEF7** on Firefly navy **#0B1D29**). Reason: near-black gives
dense rows more contrast, and **#FF3440** is a truer signal red than Station's
brick **#C5341F** — which matters in a streaming telemetry surface where harm
must register peripherally. Side-by-side comparison:
\`AstraDock Palette Decision.dc.html\`.

## 3. Accent law — RESOLVED (closes the #7 open decision)

| Role | Colour | May be used for | Must never be used for |
|---|---|---|---|
| Interaction | \`#38B6FF\` | selection rail, focus ring, active tab, links, primary action, panel corner ticks | anything conveying harm |
| Harm tier 1 "urgent" | \`#FF3440\` outlined | death, ship destroyed, disconnect — notable, not fatal | brand, primary action, focus |
| Harm tier 2 "critical" | \`#C4141F\` solid + white text | error, fatal, parse failure | brand, primary action, focus |

- Urgent = outlined chip + 9% row tint + red rail.
- Critical = solid chip, white text + 16% row tint + red rail.
- **Blue always wins the rail when a row is selected.** Red survives as the
  severity badge, so selection and severity are legible simultaneously.
- Destructive *actions* (delete mission, clear all) use solid red + white text
  on hover only — matching critical, since both mean "this causes loss."

## 4. Severity and event kind

- Hue = event kind. Weight = urgency. Nine fixed kind hues (see tokens).
- Kind hues appear **only** in the kind dot and kind tag — never on interactive
  chrome. This is what keeps kind-blue from reading as a control and kind-red
  from reading as a button.
- Urgency is never colour-alone: routine \`·\`, notice \`▲\`, urgent/critical \`■\`,
  plus a text severity label in Table mode.
- Which rules may raise a row to urgent is an explicit per-rule severity field,
  never inferred from event kind. Decide per rule when Rules are built.

## 5. Density — LOCKED

Three steps: **22 / 31 / 38px**, user-selectable, persisted **per view**.
Data rows set \`box-sizing: border-box\`, so the 1px hairline sits **inside** the
declared height — a 31px row occupies exactly 31px of pitch, not 32.
Defaults: **Terminal 22, Table 31.** Table is deliberately roomier — it carries
badges and attribute chips; Terminal carries one dense semantic line.
The 44px pointer-target rule is met by the **full-row hit area** plus keyboard
selection, not by sub-controls inside the row. This closes the density-versus-
accessibility conflict named in #7.

## 6. Panel chrome — 6a

24px mono uppercase title strip (status lives in the strip, no badge) over a
borderless bracketed body. Top and bottom hairline only, **no side borders**.
Corner ticks 11px in accent blue at top-left and bottom-right. Radius 0.
Detail fields use dotted leaders. Applies to Instruments, Party, Missions,
and the Event Detail dock.

## 7. Rows

Zebra **with** hairlines. Selection = full-row 10% blue tint + 3px blue rail +
inverted kind chip. Hover = flat fill, nothing else moves. No accordion in a
streaming table — detail is always a dock.

## 8. Detail dock

- Defaults: **right for Terminal, bottom for Table.** Override is local,
  persisted per view, resettable (#37).
- Pushes, never overlays.
- Holds a **snapshot** anchored to the immutable \`eventId\`, never row position,
  so it survives the event ageing out of the buffer.
- Shows an "N events since selection" counter.
- States: loading, not found, retention-removed, error, redacted,
  unsupported evidence.

## 9. Table vs Terminal

**Terminal** — one dense line: absolute time, kind tag, urgency glyph, summary,
context, confidence. No badges. 22px default.

**Table** — **no timestamp column.** Kind (dot + tag) · Severity badge ·
Summary · Attributes (Derived, Conf med, future badges) · Shard · Age.
Age is a relative duration, satisfying #39's event-time requirement without the
terminal's absolute clock. 31px default, 12px gaps, roomy enough for the
iconography that lands later.

## 10. Left rail — Instruments, Party, Missions

Three stacked 6a panels, each independently scrollable.

**Instruments** — only the seven authorised by #41: shard + region, server
connection + age, PU session duration, application session duration, latest
validated jurisdiction, monitored space, armistice. Plus active critical
warnings surfaced as alerts. Each carries its own qualification chip
(Current / Last confirmed / Unknown / Stale / Disconnected).

> **Cut as invented telemetry:** event rate, K/D, buffer depth, parse-error
> rate, Station link. None appear in any cited issue, and #41 names decorative
> KPI metrics and network features as explicit non-goals. Monitor freshness and
> backlog belong to the header and status bar per #42, not the cluster.

**Party** — live roster only. Members appear on join, removed on leave. Leader
carries a blue rail and a Leader tag. Scrolls when the roster outgrows the
panel. Own empty state ("Not in a party").

**Missions** — running session history, not just active. Order: **active first,
then newest.** Completed and abandoned missions persist until removed.
Per-item delete plus Clear all. Shared missions show **\`8/10 accepted\`** —
amber until every member accepts, green at full. Unshared missions show no
counter.

## 11. Shell

Header (46px): logo · environment enum · build string · monitor health +
freshness · privacy-aware source label · global actions.
Tabs (34px): Runtime Monitor (default route), Data Operations, History &
Analytics, Settings. The middle two render as **visible but unavailable**
with a Post-MVP tag — #18 lists them as MVP non-goals, and hiding them would
lose the planned-areas requirement in #33.
Status bar (24px): monitoring state · environment · local-only · retention ·
backlog · parser profile. Scrolls horizontally rather than clipping.

## 12. Cross-cutting rules

- **Unknown is never rendered as false** (#27, #31). Stale retains a
  last-confirmed value only with explicit qualification.
- Empty results distinguish **no matches** from **no telemetry** from
  **unsupported** — three separate treatments, never one generic empty state.
- **Contrast floor.** Every text token clears WCAG AA 4.5:1 against the
  *lightest* surface it can land on — \`--surface-hover #131B26\`, not the
  canvas. \`--text-ghost #78849A\` is the tightest at 4.59:1. The three darkest greys (\`#5A6675\`, \`#4A5462\`, \`#3C4656\`) are
  reclassified \`--nontext-*\` — hairlines, dotted leaders, inactive legend
  bars and disabled chrome only. They must never carry a value, label,
  timestamp or any readable string. Density is achieved with row height and
  spacing, never by dimming text below legibility.
- Sensitive IDs, endpoints and source paths are redacted on default surfaces,
  reachable only in permitted detail (#24, #25, #42).
- Filters modify one shared query and cannot cross environment partitions (#36).
  Search is bounded, debounced, literal.
- Any user sort explicitly enters browsing mode and must offer return to live
  chronology (#39, #40).
- New events raise an unseen count; they never move a browsing viewport (#40).
- Retention removal yields an explicit tombstone, never a redirect (#40).
- No third-party CDN for any production-required asset (#7).
- \`prefers-reduced-motion\` disables the live pulse and the arrival animation.

## 13. Monitor states — all must be designed

discovering · awaiting source · starting · live · paused · stale · recovering ·
disconnected/source missing · unsupported profile · degraded · stopped · error.
Each carries a text label plus a shape cue (round dot = transient/animated,
square = settled/attention), never colour alone.

---

## Still open

1. **Base shell language** — 1a instrument brackets / 1b tiling terminal /
   1c ledger spine. Runtime Monitor currently assumes 1a brackets.
2. **Metric row** — whether 2c-4 (accent tick + faded 24-bar history) replaces
   cards. Not yet needed; Instruments carry no sparklines today.
3. **Mission evidence gate** — no cited issue authorises mission extraction
   (#34 excluded, #27 names destination as a non-goal). The Missions panel is
   built to render Unsupported if the gate never lands.
4. **Party and Mission interiors** — #34, #35. Out of scope this pass.

## Reference files

- \`AstraDock Runtime Monitor.dc.html\` — the implementation-ready direction.
- \`AstraDock Palette Decision.dc.html\` — palette A/B that settled §2.
- \`AstraDock Density Directions.dc.html\` — specimen board; turn 6 panels
  (6a chrome, 6c status bar), turn 5 streaming component, turn 2 swatches.
- \`PLAN.md\` — requirement extraction from the issues.
