# AstraDock Local — Shell + Runtime Monitor design plan

Derived from `uploads/issues.json`. Primary: #7, #18, #33, #36–#42.
Supporting: #12, #22, #24, #25, #27, #29, #30, #31, #32.

## Naming

The issues call it **Runtime Monitor**, not "Log Monitor" (#18, #33, #41, #42).
Using Runtime Monitor throughout — that settles the open name question.

---

## Corrections to our interim direction

**1. The instrument cluster list was wrong.**
Our prior sketch had event rate, time since last event, uptime, shard + time in
shard, K/D, buffer depth, parse-error rate, Station link. #41 authorizes only:

- logical shard + friendly region (US/EU/AUS/ASIA/Unknown)
- server connection state + connection age
- PU session duration + application session duration
- latest validated jurisdiction (qualified Current vs Last confirmed)
- monitored space (Yes/No/Unknown/Stale)
- armistice (Yes/No/Unknown/Stale)
- active critical warnings

#41 explicitly names as non-goals: shard population, latency/FPS, exact location,
unproven destination/mission/ship/combat, decorative KPI metrics. **K/D, buffer
depth, parse-error rate and event rate are not in any cited issue** — they are
invented telemetry and are cut. Monitor freshness/backlog belongs to the header
per #42, not the cluster. Station link is out (#18 non-goal: no network features).

**2. The accent system is still an open decision.**
#7 lists signal-red vs Presstronic/Station blue vs explicit semantic mapping as
unresolved, and says UI must not hard-code competing specimen values. Our locked
palette is therefore an *assumption*, annotated as such in the design, expressed
through semantic tokens (primary action / focus / info / success / warning /
danger / event-kind / urgency) so the accent can be reassigned in one place.

**3. Density vs. hit targets is an explicit open problem, not a free choice.**
#7 calls out resolving "how dense 26px data rows coexist with accessible
interactive targets." Our 22/31/38 picker stays, but rows carry a full-row hit
area and keyboard-first selection so the 44px pointer-target rule is met by the
row, not by sub-controls inside it.

---

## Shell (#33, #42)

Regions: persistent header (source / environment / lifecycle / monitor health),
workspace tabs, instrument cluster, Party region, Mission region, attention &
warnings, stream view + controls, drilldown host.

Tabs — planned areas shown, interiors not designed except Runtime Monitor:
Runtime Monitor (default startup route), Data Operations and History & Analytics
(post-MVP per #18 non-goals, so present but explicitly unavailable), Settings
(#30). Party and Mission are *regions inside Runtime Monitor* per #33 scope, not
tabs — their interiors (#34, #35) are excluded from this pass.

Header data (#42): environment as uppercase enum LIVE/PTU/EPTU/HOTFIX/UNKNOWN;
build/branch/changelist as opaque strings, never numeric-rounded; privacy-aware
source label with full path only in explicit detail; freshness as compact
relative duration (12s, 3m 08s); backlog integers only when degraded.

Monitoring states (#42): discovering, awaiting source, starting, live, paused,
stale, recovering, disconnected/source missing, unsupported profile, degraded,
stopped, error.

Shell states (#33): loading, no-source, recovering, ready, stale, disconnected,
unsupported-profile, fatal/degraded.

## Runtime Monitor

**Stream model (#40).** One environment/session-scoped subscription feeding both
views. Live edge and browse anchor modelled independently — new events raise the
unseen count without moving a browsing viewport. Mode labels: Live, Browsing,
Paused, Stale, Disconnected, Replay. Retention removal yields an explicit
tombstone, never a redirect.

**Terminal (#38).** Dense semantic lines: time, event-kind label, concise
summary, context, urgency, confidence where material. Default **right** drawer.

**Table (#39).** Core columns: event time, event-kind label, summary, environment/
session context, confidence/qualification, urgency. Responsive-optional: shard,
party subject, provenance. Default **bottom** drawer. Any user sort explicitly
enters browsing mode and must offer return to live chronology.

**Selection & drilldown (#37).** Anchored to immutable eventId, never row
position. Placement override is local, persisted, resettable. Events-since-
selection counter. States: loading, not found, retention-removed, error,
redacted, unsupported evidence.

**Filters & alerts (#36).** Filters modify the one shared query and cannot cross
environment partitions. Search bounded, debounced, literal. Alerts derive from
validated transitions, carry severity + supporting event IDs, and distinguish
auto-clearing from historical. Empty results must distinguish *no matches* from
*no telemetry* from *unsupported*.

## Cross-cutting rules

- Unknown is never rendered as false (#27, #31). Stale retains last-confirmed
  value only with explicit qualification.
- Event kind, urgency, and every state are distinguishable without color alone
  (#7, #36, #38, #39).
- Sensitive IDs, endpoints, and source paths are redacted on default surfaces and
  reachable only in permitted detail (#24, #25, #42).
- No third-party CDN for any production-required asset (#7).

## Party and Mission regions — confirmed requirements (user, Aug 10)

Both live in the left rail as two separate panels, each independently
scrollable.

**Party.** Live roster only. Members appear as they join and are removed as they
leave. Scrolls once the roster outgrows its panel.

**Mission.** A running history for the play session, not just active missions.
Completed missions stay in the list. Per-item delete (missions get abandoned)
and a clear-all. Each *shared* mission shows an acceptance count against party
size — one or two words max, e.g. `8/10 accepted`. Unshared missions show no
counter.

Note: mission data has no validated extraction gate in the cited issues (#27
names exact location/destination as non-goals; #34 is excluded). So the Mission
panel is designed as shell + interaction model with its data state driven by
evidence availability — it must be able to render Unsupported rather than empty.

## Open assumptions to confirm

1. Accent system (see above) — carried forward from interim work, not approved.
2. Party and Mission as in-shell regions rather than tabs.
3. Data Operations / History & Analytics shown as visible-but-unavailable tabs
   rather than omitted entirely.
